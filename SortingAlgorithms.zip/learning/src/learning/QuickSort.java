package learning;

import java.util.Iterator;

public class QuickSort {
	int[] list;
	int[] sortedListQuick;
	
	QuickSort(int[] list){
		this.list=list;
		sortedListQuick=quickSort(list);
	}
	public void printArray() {
		for (int i = 0; i < list.length; i++) {
			System.out.println(sortedListQuick[i]);
		}
	}
	
	public int[] quickSort(int[] arr) {
		boolean currentPointer=true;
		int pivot=arr[0];
		int leftPointer=0;
		int rightPointer=arr.length-1;
		while (leftPointer!=rightPointer) {
			if (currentPointer) {
				//According to right side
				if (pivot>arr[rightPointer]) {
					arr[leftPointer]=arr[rightPointer];
					leftPointer++;
					currentPointer=false;
				} else {
					rightPointer--;
				}
			}
			else{
				if (pivot<arr[leftPointer]) {
					arr[rightPointer]=arr[leftPointer];
					rightPointer--;
					currentPointer=true;
				}
				else {
					leftPointer++;
				}
			}
		}
		arr[leftPointer]=pivot;
		if (leftPointer>1) {
			int[] leftSub=new int[leftPointer];
			for (int i = 0; i < leftSub.length; i++) {
				leftSub[i]=arr[i];
			}
			leftSub=quickSort(leftSub);
			for (int i = 0; i < leftSub.length; i++) {
				arr[i]=leftSub[i];
			}
		}

		if (arr.length-1-leftPointer>1) {
			int[] rightSub=new int[arr.length-1-leftPointer];
			for (int i = 0; i < rightSub.length; i++) {
				rightSub[i]=arr[leftPointer+1+i];
			}
			rightSub=quickSort(rightSub);
			for (int i = 0; i < rightSub.length; i++) {
				arr[leftPointer+1+i]=rightSub[i];
			}
		}
		return arr;
	}

}
