package learning;

public class MergeSort {
	private int[] list;
	private int[] listMergeSorted;
	
	public MergeSort(int[] list) {
		this.list=list;
		this.listMergeSorted=sort(list);
	}
	public void printArray() {
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);
		}
	}
	private int[] sort(int[] list) {
		int middleIndex=(list.length/2);
		if (list.length%2==1) {
			middleIndex++;
		}
		int[] leftSub=splitArray(list, 0, middleIndex);
		int[] rightSub=splitArray(list, middleIndex, list.length);
		if (leftSub.length>1) {
			leftSub=sort(leftSub);
		}
		if (rightSub.length>1) {
			rightSub=sort(rightSub);
		}
		return addingTwoArray(leftSub, rightSub);
	}
	public int[] splitArray(int[] source, int startIndex, int endIndex) {
		int[] returnedArray=new int[endIndex-startIndex];
		int pointer1=0;
		for (int i = startIndex; i < endIndex; i++) {
			returnedArray[pointer1]=source[i];
			pointer1++;
		}
		return returnedArray;
	}
	public static int[] addingTwoArray(int[] arr1, int[] arr2) {
		int[] addedArray=new int[arr1.length+arr2.length];
		int pointer1=0;
		int pointer2=0;
		int pointer3=0;
		while (pointer3!=addedArray.length) {
			if (pointer1==arr1.length) {
				while (pointer2!=arr2.length) {
					addedArray[pointer3]=arr2[pointer2];
					pointer2++;
					pointer3++;
				}
				break;
			}
			if (pointer2==arr2.length) {
				while (pointer1!=arr1.length) {
					addedArray[pointer3]=arr1[pointer1];
					pointer1++;
					pointer3++;
				}	
				break;
			}
			if (arr1[pointer1]<arr2[pointer2]) {
				addedArray[pointer3]=arr1[pointer1];
				pointer1++;
			}
			else {
				addedArray[pointer3]=arr2[pointer2];
				pointer2++;
			}
			pointer3++;
		}
		return addedArray;
	}
}
