package learning;

import java.util.*;
/*
 * this program is done for learning, by comparing the speeds of bubble sort, merge sort and quick sort
 * As a result, bubble sort and quick sort are fastest sorting algorithms working on divide and conquer principle
 * but in the case of using short arrays, bubble sort is faster than others 
 * 
 * recursive programming approach is used
 * 
 * 
 * */
public class learning {
	public static void main(String[] args) {
		//Merge sorting
		int[] arrayMerge= {38,27,43,3,9,82,10};
		long firstMerge=System.nanoTime();
		MergeSort mergeSort=new MergeSort(arrayMerge);
		long finalMerge=System.nanoTime();
		//mergeSort.printArray();
		System.out.println("Merge sort:  "+Math.abs(firstMerge-finalMerge));

		//Quick sort
		int[] arrayQuick= {38,27,43,3,9,82,10};
		long firstQuick=System.nanoTime();
		QuickSort quickSort=new QuickSort(arrayQuick);
		long finalQuick=System.nanoTime();
		System.out.println("Quick sort:  "+Math.abs(firstQuick-finalQuick));
		//Bubble sort
		int[] arrayBubble= {38,27,43,3,9,82,10};
		long firstBubble=System.nanoTime();
		for (int i = 0; i < arrayBubble.length; i++) {
			for (int j = 0; j < arrayBubble.length; j++) {
				if (arrayBubble[i]>arrayBubble[j]) {
					int temp = arrayBubble[i];
					arrayBubble[i]=arrayBubble[j];
					arrayBubble[j]=temp;
				}
			}
		}
	
		long finalBubble=System.nanoTime();
		System.out.println("bubble sort: "+Math.abs(finalBubble-firstBubble));

		
	}

}
